import { kv } from '@vercel/kv';

// Clave única donde vive el historial compartido de toda la empresa
const KEY = 'va_historial';

export default async function handler(req, res) {
  try {
    if (req.method === 'GET') {
      // Devuelve el historial completo (array), o vacío si no hay nada
      const data = (await kv.get(KEY)) || [];
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      // Agrega una cotización nueva al principio del historial
      const nueva = req.body;
      if (!nueva || !nueva.nombre) {
        return res.status(400).json({ error: 'Faltan datos de la cotización.' });
      }
      const actual = (await kv.get(KEY)) || [];
      const item = { ...nueva, id: Date.now() };
      const actualizado = [item, ...actual];
      await kv.set(KEY, actualizado);
      return res.status(200).json(item);
    }

    if (req.method === 'DELETE') {
      // ?id=123 borra una; sin id, vacía todo
      const { id } = req.query;
      if (id) {
        const actual = (await kv.get(KEY)) || [];
        await kv.set(KEY, actual.filter(h => String(h.id) !== String(id)));
      } else {
        await kv.set(KEY, []);
      }
      return res.status(200).json({ ok: true });
    }

    res.setHeader('Allow', 'GET, POST, DELETE');
    return res.status(405).json({ error: 'Método no permitido' });
  } catch (e) {
    return res.status(500).json({ error: 'Error del servidor: ' + e.message });
  }
}
