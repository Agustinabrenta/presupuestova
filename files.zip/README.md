# Vuelo Aventura — Cotizador con historial compartido

Historial único para toda la empresa: todos ven y editan las mismas cotizaciones,
desde cualquier computadora. Guardado en Vercel KV (base de datos en la nube).

## Qué cambió respecto a la versión de HTML único

- El **historial** ya no vive en el navegador de cada uno. Vive en el servidor,
  compartido. Por eso ya no alcanza con pegar un HTML: hace falta este proyecto
  con la carpeta `/api`.
- El **catálogo, los términos y condiciones y los datos de la empresa** siguen
  siendo locales de cada navegador (es configuración tuya, no cambia por cliente).
- Las **imágenes NO se guardan en el historial** (pesan demasiado para una base
  compartida). Al regenerar el PDF de una cotización vieja, la app toma la foto
  ACTUAL del catálogo que coincida por nombre de opción. Si cambiaste la foto de
  esa opción, el PDF viejo saldrá con la foto nueva. Para la mayoría de los casos
  esto está perfecto.

## Estructura

```
vuelo-aventura/
├── api/
│   └── historial.js      ← función serverless (leer/guardar/borrar)
├── public/
│   └── index.html        ← la página
├── package.json          ← declara la dependencia @vercel/kv
└── README.md
```

## Cómo desplegarlo en Vercel (paso a paso)

Como hoy lo pegaste como HTML suelto, hay que pasar a un proyecto. Lo más simple:

### Opción A — Subir por Git (recomendada)
1. Creá un repositorio en GitHub y subí esta carpeta completa.
2. En Vercel: **Add New → Project → Import** el repo.
3. Framework preset: **Other**. Dejá todo por defecto y **Deploy**.

### Opción B — Vercel CLI (sin Git)
1. Instalá la CLI: `npm i -g vercel`
2. Dentro de la carpeta `vuelo-aventura/`, corré: `vercel`
3. Seguí los pasos; cuando termine te da la URL.

## Conectar la base de datos (Vercel KV) — IMPRESCINDIBLE

Sin esto, el historial no funciona (la app va a decir "no se pudo cargar").

1. En tu proyecto de Vercel, andá a la pestaña **Storage**.
2. **Create Database → KV** (Redis). Ponele un nombre (ej: `cotizaciones`).
3. Cuando te pregunte, **conectala a este proyecto** (Connect Project).
   Esto crea solas las variables de entorno que la app necesita
   (`KV_REST_API_URL`, `KV_REST_API_TOKEN`, etc.). No tenés que copiar nada a mano.
4. Volvé a **Deployments** y hacé **Redeploy** del último deploy, para que tome
   las variables nuevas.

Listo. Abrí tu URL, andá a la pestaña **Historial**, generá una cotización de
prueba y verificá que aparezca. Abrí la misma URL en otra compu o navegador:
tenés que ver la misma cotización. Eso confirma que el historial es compartido.

## Notas

- Si ves "No se pudo cargar el historial", casi siempre es que falta el paso de
  Storage/KV o que no hiciste Redeploy después de conectarlo.
- El botón **Vaciar historial** borra para TODOS. Está detrás de una confirmación.
- KV en el plan gratis de Vercel alcanza de sobra para este volumen.
